import numpy as np
from copy import deepcopy

class structure:
    def __init__(self, position =[0,0], cost = np.inf):
        self.position = position
        self.cost = cost

def crossOver(p1,p2):
    c1 = deepcopy(p1)
    c2 = deepcopy(p2)
    
    gamma = 0.5
    alpha = np.random.uniform(low=0, high=gamma)
    
    c1.position = (1-alpha)*p1.position + alpha*p2.position
    c2.position = (1-alpha)*p2.position + alpha*p1.position
    
    return c1, c2
    
    
def mutate(x, mu, sigma):
    y = deepcopy(x)
    flag = (np.random.rand(*x.position.shape) <= mu)
    ind = np.argwhere(flag)
    
    y.position[ind] += sigma*np.random.uniform(low=-1, high=1)
    return y

def runGA(problem,params):
    costFunc = problem.costFunc
    nVar = problem.nVar
    varMin = problem.varMin
    varMax = problem.varMax
    
    maxIt = params.maxIt
    nPop = params.nPop
    mu = params.mu
    sigma = params.sigma
    pc = params.pc
    nc = int(np.round(pc*nPop/2)*2)
      
    empty_individual = structure()
    
    bestSol = deepcopy(empty_individual)
    bestSol.cost = np.inf
    
    pop = []
    for i in range(nPop):
        pop.append(deepcopy(empty_individual))
    
    for i in range(nPop):
        temp = deepcopy(empty_individual)
        temp.position = np.random.uniform(varMin,varMax,nVar)
        
        C = 0;
        ct = 3;
        for _ in range(ct):
            C += costFunc(temp.position)
                
        temp.cost = C/ct
        
        pop[i].position = deepcopy(temp).position
        pop[i].cost = deepcopy(temp).cost
        
        if(pop[i].cost < bestSol.cost):
            bestSol = deepcopy(temp)
        
    
    for it in range(maxIt):
        popc = []
        
        mu = params.mu/(round(it/(maxIt/5)) + 1)
        
        for _ in range(nc//2):
            q = np.random.permutation(nPop)
            
            p1 = deepcopy(pop[q[0]])
            p2 = deepcopy(pop[q[1]])
            
            c1,c2 = crossOver(p1,p2)
            
            c1 = mutate(c1, mu, sigma)
            c2 = mutate(c2, mu, sigma)
            
            c1.position = np.minimum(c1.position,varMax)
            c2.position = np.minimum(c2.position,varMax)
            
            c1.position = np.maximum(c1.position,varMin)
            c2.position = np.maximum(c2.position,varMin)
            
            
            ct = 3;
            
            C = 0;
            for _ in range(ct):
                C += costFunc(c1.position)
                    
            c1.cost = C/ct
            
            
            C = 0;
            for _ in range(ct):
                C += costFunc(c2.position)
                    
            c2.cost = C/ct
            
            if c1.cost < bestSol.cost:
                bestSol = deepcopy(c1)
                
            if c2.cost < bestSol.cost:
                bestSol = deepcopy(c2)
                
            popc.append(c1)
            popc.append(c2)
    
            pop += popc
            
            pop = sorted(pop,key=lambda x: x.cost)
            pop = pop[0:nPop]
            
        print(bestSol.cost,bestSol.position,mu)
    
    # asd = []
    # for af in range(nPop):
        # asd.append(pop[af].cost)
        
    # print(asd)   sd = []
    # for af in range(nPop):
        # asd.append(pop[af].cost)
        
    # print(asd)    
        
    return bestSol